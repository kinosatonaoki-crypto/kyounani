/**
 * Vercel Serverless Function
 * POST /api/comment
 * Anthropic APIキーをサーバー側で保持し、フロントエンドに漏れないようにするプロキシ
 */
export default async function handler(req, res) {
  // CORS
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "ANTHROPIC_API_KEY is not configured" });
  }

  const { weatherData } = req.body || {};
  if (!weatherData) {
    return res.status(400).json({ error: "weatherData is required" });
  }

  const { temp, feels, maxTemp, minTemp, code, hum, rain, wind } = weatherData;

  const weatherLabels = {
    0: "快晴", 1: "晴れ", 2: "晴れ時々曇り", 3: "曇り",
    45: "霧", 48: "霧",
    51: "霧雨", 53: "霧雨", 55: "霧雨",
    61: "雨", 63: "雨", 65: "雨",
    80: "にわか雨", 81: "にわか雨", 82: "にわか雨",
    95: "雷雨", 96: "雷雨", 99: "雷雨",
  };
  const wLabel = weatherLabels[code] || "くもり";

  const prompt =
    `和歌山県上富田町の今日の天気：気温${temp}℃（体感${feels}℃）、` +
    `最高${maxTemp}℃・最低${minTemp}℃、${wLabel}、` +
    `湿度${hum}%、降水確率${rain}%、風速${wind}m/s。\n` +
    `上富田町に住む高齢者向けに、今日の天気に合わせた温かみのあるアドバイスを日本語で2〜3文書いてください。` +
    `季節感、外出のタイミング、健康アドバイスを自然に含め、フレンドリーで温かみのある文体でお願いします。`;

  try {
    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 300,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    const data = await upstream.json();

    if (!upstream.ok) {
      console.error("Anthropic API error:", data);
      return res.status(upstream.status).json({ error: data.error?.message || "Anthropic API error" });
    }

    const text = (data.content || []).map((b) => b.text || "").join("").trim();
    return res.status(200).json({ comment: text });
  } catch (err) {
    console.error("Proxy error:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
}
